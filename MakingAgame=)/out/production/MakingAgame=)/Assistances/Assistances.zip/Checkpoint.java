package Assistances;

public class Checkpoint {
    private int xDirection,yDirection,xCoor,yCoor;

    public Checkpoint(){
        this.xCoor=0;
        this.yCoor=0;
        this.xDirection=0;
        this.yDirection=0;
    }

    public Checkpoint(int xDirection, int yDirection, int xCoor, int yCoor) {
        this.xDirection = xDirection;
        this.yDirection = yDirection;
        this.xCoor = xCoor;
        this.yCoor = yCoor;
    }
    /*
    public Checkpoint(Checkpoint checkpoint){
        this.xCoor=checkpoint.getxCoor();
        this.yCoor=checkpoint.getyCoor();
        this.xDirection=checkpoint.getxDirection();
        this.yDirection=checkpoint.getyDirection();
    }*/

    public int getxDirection() {
        return xDirection;
    }

    public void setxDirection(int xDirection) {
        this.xDirection = xDirection;
    }

    public int getyDirection() {
        return yDirection;
    }

    public void setyDirection(int yDirection) {
        this.yDirection = yDirection;
    }

    public int getxCoor() {
        return xCoor;
    }

    public void setxCoor(int xCoor) {
        this.xCoor = xCoor;
    }

    public int getyCoor() {
        return yCoor;
    }

    public void setyCoor(int yCoor) {
        this.yCoor = yCoor;
    }

}
