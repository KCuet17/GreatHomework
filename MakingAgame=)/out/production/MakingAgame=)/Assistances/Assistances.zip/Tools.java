package Assistances;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Tools {
    public static final int map[][]={
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,2,2},
            {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2},
            {1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2}};


    public static final int WIDTH=1280, HEIGHT=704;

    public static void DrawMap(int map[][],GraphicsContext gc) {
        //Draw a map
        Image road= new Image("mapTile_082.png");
        Image moutain= new Image("mapTile_022.png");
        Image shop= new Image("road.png");

        float x = 0;
        float y = 0;
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                if (map[i][j] == 0)
                    gc.drawImage( road, x, y);
                else if (map[i][j] == 1)
                    gc.drawImage(moutain, x, y);
                else if (map[i][j] == 2)
                    gc.drawImage(shop, x, y);
                x += 64;
            }
            x = 0;
            y += 64;
        }
    }


}
