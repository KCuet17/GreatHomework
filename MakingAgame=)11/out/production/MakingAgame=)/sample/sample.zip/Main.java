package sample;

import Tower.AbstractTower;
import Tower.NormalTower;
import javafx.animation.AnimationTimer;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import sample.Enemy.AbstractEnemy;
import sample.Enemy.NormalEnemy;
import sample.Enemy.SmallerEnemy;
import sample.Enemy.TankerEnemy;

import java.util.ArrayList;
import java.util.Random;

import static Assistances.Tools.DrawMap;


public class Main extends Application {
    public int map[][]={
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,2,2},
            {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2},
            {1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2}};

    public static final int WIDTH=1280, HEIGHT=704;
    private Image image1= new Image("mapTile_171.png");

    @Override
    public void start(Stage theStage) throws Exception
    {
        //BeginSession(theStage);
        theStage.setTitle( "Tower Defense" );
        //Tao mot group moi trong Stage
        Group root = new Group();
        //Tao man hinh choi moi
        Scene GameField = new Scene( root );
        //add man hinh choi vao Stage
        theStage.setScene( GameField );
        //Tao 2 canvas moi, canvas giong nhu mot layer de ve
        Canvas canvas1= new Canvas(WIDTH,HEIGHT); // canvas1 ve map
        Canvas canvas2= new Canvas(WIDTH,HEIGHT); // canvas2 ve doi tuong dong
        //add canvas vao root
        root.getChildren().add(canvas1);
        root.getChildren().add(canvas2);
        //gc la cong cu de ve
        GraphicsContext gc1 = canvas1.getGraphicsContext2D();
        GraphicsContext gc2= canvas2.getGraphicsContext2D();
        // ve map
        DrawMap(map,gc1);
        ArrayList<AbstractEnemy> enemyList= new ArrayList<>();
        //spawn a tower
        ArrayList<AbstractTower> towerList= new ArrayList<>();
        towerList.add(new NormalTower(0,64*9,64*5));
        towerList.add(new NormalTower(0,64*8,64*2));
        towerList.add(new NormalTower(0,64*12,64*8));

        Timeline gameLoop = new Timeline();
        gameLoop.setCycleCount( Timeline.INDEFINITE );

        //mouse button

        final long startNanoTime = System.nanoTime();

        new AnimationTimer()
        {
            long tick=0;
            int count=0;
            public void handle(long currentNanoTime)
            {
                if(count==1){
                    gc1.clearRect(0,0,WIDTH,HEIGHT);
                    gc1.drawImage(image1,0,0,WIDTH,HEIGHT);
                    gc2.clearRect(0,0,WIDTH,HEIGHT);
                    gc2.setFill( Color.RED );
                    gc2.setStroke( Color.DARKRED );
                    gc2.setLineWidth(2);
                    Font theFont = Font.font( "Times New Roman", FontWeight.BOLD, 100 );
                    gc2.setFont( theFont );
                    gc2.fillText( "You Lose! " , 64*6, 64*5 );
                    gc2.strokeText( "You Lose! ", 64*6, 64*5 );

                }
                else {
                    if (tick % 200 == 0) {
                        Random rd= new Random();
                        int number= rd.nextInt(3);
                        if(number==0) {
                            NormalEnemy enemy = new NormalEnemy();
                            enemyList.add(enemy);
                        }
                        else if(number==1){
                            SmallerEnemy enemy= new SmallerEnemy();
                            enemyList.add(enemy);
                        }
                        else if(number==2){
                            TankerEnemy enemy= new TankerEnemy();
                            enemyList.add(enemy);
                        }
                    }
                    gc2.clearRect(0, 0, WIDTH, HEIGHT);
                    for (int i = enemyList.size()-1; i >=0 ; i--) {
                        enemyList.get(i).update(gc2);
                        if (enemyList.get(i).getCounter() == 7 ) {
                            enemyList.remove(i);
                            count++;
                        }
                        if(enemyList.get(i).getHealth()<=0){
                            enemyList.remove(i);
                        }
                    }
                    for(int i=0;i<towerList.size();i++){
                        for(int j=enemyList.size()-1;j>=0;j--){
                            if(towerList.get(i).getCenter().Distance(enemyList.get(j).getCenter())<= towerList.get(i).getRange())
                                towerList.get(i).setEnemy(enemyList.get(j));
                        }
                        towerList.get(i).setTick(tick);
                        towerList.get(i).update(gc2);
                    }
                    tick++;
                }
            }
        }.start();

        theStage.show();
    }


    public static void main(String[] args) {
        launch(args);

    }
}
