package sample;

import  Assistances.Checkpoint;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.awt.*;
import java.util.ArrayList;

public class Enemy {
    public static final int map[][]={
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,2,2},
            {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2},
            {1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2},
            {1,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,2,2},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2}};
    public final int Xstart=1,Ystart=1,Xend=16,Yend=9;

    private int x,y,speed,heatlh;
    private boolean Alive;
    private int XDirection,YDirection;
    private ArrayList<Checkpoint> checkpointList= new ArrayList<Checkpoint>();
    private int counter;
    private Image image;

    public Enemy() {
        this.image= new Image("enemy4.png");
        this.x=Xstart*64;
        this.y=Ystart*64;
        this.speed=2;
        this.heatlh=100;
        this.Alive=true;
        this.XDirection=1;
        this.YDirection=0;
        this.counter=0;
        Checkpoint checkpoint1=new Checkpoint(0,1,15*64,64);
        Checkpoint checkpoint2=new Checkpoint(-1,0,15*64,4*64);
        Checkpoint checkpoint3=new Checkpoint(0,1,4*64,4*64);
        Checkpoint checkpoint4=new Checkpoint(1,0,4*64,7*64);
        Checkpoint checkpoint5=new Checkpoint(0,1,11*64,7*64);
        Checkpoint checkpoint6=new Checkpoint(1,0,11*64,9*64);
        Checkpoint checkpoint7=new Checkpoint(0,0,16*64,9*64);
        checkpointList.add(checkpoint1);
        checkpointList.add(checkpoint2);
        checkpointList.add(checkpoint3);
        checkpointList.add(checkpoint4);
        checkpointList.add(checkpoint5);
        checkpointList.add(checkpoint6);
        checkpointList.add(checkpoint7);
    }

    public Enemy(int n) {
        this.image= new Image("enemy"+n+".png");
        this.x=Xstart*64;
        this.y=Ystart*64;
        this.speed=2;
        this.heatlh=100;
        this.Alive=true;
        this.XDirection=1;
        this.YDirection=0;
        this.counter=0;
        Checkpoint checkpoint1=new Checkpoint(0,1,15*64,64);
        Checkpoint checkpoint2=new Checkpoint(-1,0,15*64,4*64);
        Checkpoint checkpoint3=new Checkpoint(0,1,4*64,4*64);
        Checkpoint checkpoint4=new Checkpoint(1,0,4*64,7*64);
        Checkpoint checkpoint5=new Checkpoint(0,1,11*64,7*64);
        Checkpoint checkpoint6=new Checkpoint(1,0,11*64,9*64);
        Checkpoint checkpoint7=new Checkpoint(0,0,16*64,9*64);
        checkpointList.add(checkpoint1);
        checkpointList.add(checkpoint2);
        checkpointList.add(checkpoint3);
        checkpointList.add(checkpoint4);
        checkpointList.add(checkpoint5);
        checkpointList.add(checkpoint6);
        checkpointList.add(checkpoint7);
    }

    public void Draw(GraphicsContext gc){
        gc.drawImage(this.image,x,y);
    }
    public void update() {
        if(counter==7){
            this.XDirection=0;
            this.YDirection=0;
        }
        else if(this.isPass()) {
            this.XDirection = this.checkpointList.get(counter).getxDirection();
            this.YDirection = this.checkpointList.get(counter).getyDirection();
            counter++;
        }

        this.x+=speed*this.XDirection;
        this.y+=speed*this.YDirection;
    }

    /*
    public Checkpoint findNext(int map[][]){
        int counter=1;
        Checkpoint checkpoint= new Checkpoint();
        boolean cont=true;
        while(cont){
            if(XDirection==1){
                if(map[x/64-1+counter][y/64-1]==1) {
                    checkpoint.setxCoor(x/64+counter-2);
                    checkpoint.setyCoor(y/64-1);
                    checkpoint.setxDirection(0);
                    checkpoint.setyDirection(1);
                    cont = false;
                }
            }
            else if(XDirection==-1){
                if(map[x/64-1-counter][y/64-1]==1){
                    checkpoint.setxCoor(x/64+counter);
                    checkpoint.setyCoor(y/64-1);
                    checkpoint.setxDirection(0);
                    checkpoint.setyDirection(1);
                    cont = false;
                }
            }
            else if(YDirection==1){
                if(map[x/64-1][y/64-1+counter]==1 && map[x/64][y/64-2+counter]==0){
                    checkpoint.setxCoor(x/64-1);
                    checkpoint.setyCoor(y/64-2+counter);
                    checkpoint.setxDirection(1);
                    checkpoint.setyDirection(0);
                    cont=false;
                }
                else if(map[x/64-1][y/64-1+counter]==1 && map[x/64-2][y/64-2+counter]==0){
                    checkpoint.setxCoor(x/64-1);
                    checkpoint.setyCoor(y/64-2+counter);
                    checkpoint.setxDirection(-1);
                    checkpoint.setyDirection(0);
                    cont=false;
                }
            }
            counter++;
        }
        return checkpoint;
    }
    public boolean isPass(){
        return ( this.x==this.checkpoint.getxCoor() && this.y==this.checkpoint.getyCoor());
    }*/

    public boolean isPass(){
        return(this.x==this.checkpointList.get(counter).getxCoor() && this.y==this.checkpointList.get(counter).getyCoor());
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getSpeed() {
        return speed;
    }

    public int getHeatlh() {
        return heatlh;
    }

    public boolean isAlive() {
        return Alive;
    }
}
