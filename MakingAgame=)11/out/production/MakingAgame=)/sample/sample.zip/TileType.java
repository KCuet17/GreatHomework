package sample;

public enum TileType {

    Moutain("mountain.png",true),Road("road.png",false),
    Shop("shop.png",false);


    String url;
    boolean buildable;

    TileType(String url,boolean buildable){
        this.buildable=buildable;
        this.url=url;

    }
}
