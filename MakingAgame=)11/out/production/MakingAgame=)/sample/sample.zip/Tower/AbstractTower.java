package Tower;

import javafx.scene.canvas.GraphicsContext;

import sample.AbstractEntity;
import sample.Enemy.AbstractEnemy;
import Assistances.Point;

import java.awt.*;
import java.util.ArrayList;

public abstract class AbstractTower<AbstractBullet > extends AbstractEntity {
    protected final double range;
    protected final long speed;
    protected ArrayList<AbstractBullet> bullets;
    protected Image towerImage;
    protected AbstractEnemy enemy;
    protected Point center;

    protected long tick;

    protected AbstractTower(long createdTick, double X, double Y, double range, long speed) {
        super(createdTick, X, Y, 64,64 );
        this.range = range;
        this.speed = speed;
        this.tick = 60;
        this.center=new Point((long)X+32,(long)Y+32);
        this.enemy=null;
        this.bullets= new ArrayList<>();
    }
    public abstract void update(GraphicsContext gc);
    public void setEnemy(AbstractEnemy enemy){
        this.enemy=enemy;
    }

    public AbstractEnemy getEnemy() {
        return enemy;
    }

    public  double findDeltaX(){
        if(enemy!=null)
        return (this.enemy.getCenter().getX()-this.center.getX())/this.center.Distance(this.enemy.getCenter());
        return 0;
    }
    public  double findDeltaY(){
        if(enemy!=null)
        return (this.enemy.getCenter().getY()-this.center.getY())/this.center.Distance(this.enemy.getCenter());
        return 0;
    }

    protected abstract AbstractBullet doSpawn();
    protected abstract void Draw(GraphicsContext gc);

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    public long getTick() {
        return tick;
    }

    public void setTick(long tick) {
        this.tick = tick;
    }

    public double getRange() {
        return range;
    }

    public long getSpeed() {
        return speed;
    }
}
