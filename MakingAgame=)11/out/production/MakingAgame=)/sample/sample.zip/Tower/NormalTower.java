package Tower;


import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import sample.Bullet.NormalBullet;

public class NormalTower extends AbstractTower <NormalBullet>{
    private Image image= new Image("castle.png");

    public NormalTower(long createdTick, int X, int Y) {
        super(createdTick, X, Y, 2*64, 5);
    }

    @Override
    public void Draw(GraphicsContext gc){
        gc.drawImage(this.image,this.X,this.Y,this.width,this.height);
    }
    @Override
    public void update(GraphicsContext gc){
        if(enemy!=null) {
            if (this.getTick() % 50 == 0) {
                this.bullets.add(this.doSpawn());
            }
            for (int i = 0; i < this.bullets.size(); i++) {

                if (Math.abs(this.bullets.get(i).getX() - this.enemy.getCenter().getX()) <= 10
                        && Math.abs(this.bullets.get(i).getY() - this.enemy.getCenter().getY()) <= 10) {
                     this.bullets.remove(i);
                     this.enemy.getDamage(20);
                }
                if(Math.abs(this.bullets.get(i).getX() - this.getX()) >= this.getRange() &&
                        Math.abs(this.bullets.get(i).getY() - this.getY()) >= this.getRange()) {
                    this.bullets.remove(i);
                }
                if(this.center.Distance(enemy.getCenter())>=this.range) this.enemy=null;
                this.bullets.get(i).BulletUpdate(gc);
            }
            if(enemy.getHealth()<=0) enemy= null;
        }
        this.Draw(gc);
    }
    @Override
    public NormalBullet doSpawn(){
        return new NormalBullet(60,this.getX()+32,this.getY()+32,this.findDeltaX(),this.findDeltaY());
    }

}
