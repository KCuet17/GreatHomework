package sample.Bullet;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;


public class NormalBullet extends AbstractBullet {
    private Image image= new Image("NormalBullet.png");
    public NormalBullet(long createdTick, double posX, double posY, double deltaX, double deltaY) {
        super(createdTick, posX, posY, deltaX, deltaY, 3,20,60,15);
    }
    @Override
    public void Draw(GraphicsContext gc){
        gc.drawImage(this.image,this.getX(),this.getY(),this.width,this.height);
    }

}
