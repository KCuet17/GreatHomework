package sample.Enemy;

import Assistances.Checkpoint;
import Assistances.Point;
import javafx.scene.canvas.GraphicsContext;
import sample.AbstractEntity;

import java.util.ArrayList;

public abstract class AbstractEnemy extends AbstractEntity {
    protected double speed;
    protected int XDirection,YDirection;
    protected int counter;
    protected ArrayList<Checkpoint> checkpointList;
    protected long reward,health;
    protected boolean Alive;
    protected Point center;

    public AbstractEnemy(long createTick,double posX,double posY,long size, long health,double speed,long reward){
        super(createTick,posX,posY,size,size);
        this.health=health;
        this.speed=speed;
        this.reward=reward;
        this.XDirection=1;
        this.YDirection=0;
        this.counter=0;
        this.center= new Point((long)posX+32,(long)posY+32);
        this.checkpointList= new ArrayList<>();
        Checkpoint checkpoint1=new Checkpoint(0,1,15*64,64);
        Checkpoint checkpoint2=new Checkpoint(-1,0,15*64,4*64);
        Checkpoint checkpoint3=new Checkpoint(0,1,4*64,4*64);
        Checkpoint checkpoint4=new Checkpoint(1,0,4*64,7*64);
        Checkpoint checkpoint5=new Checkpoint(0,1,11*64,7*64);
        Checkpoint checkpoint6=new Checkpoint(1,0,11*64,9*64);
        Checkpoint checkpoint7=new Checkpoint(0,0,16*64,9*64);
        checkpointList.add(checkpoint1);
        checkpointList.add(checkpoint2);
        checkpointList.add(checkpoint3);
        checkpointList.add(checkpoint4);
        checkpointList.add(checkpoint5);
        checkpointList.add(checkpoint6);
        checkpointList.add(checkpoint7);
    }

    public abstract void Draw(GraphicsContext gc);

    public boolean isPassed(){
        if(this.XDirection>0) return this.getX()>=this.checkpointList.get(counter).getxCoor();
        if(this.XDirection<0) return this.getX()<=this.checkpointList.get(counter).getxCoor();
        if(this.YDirection>0) return this.getY()>=this.checkpointList.get(counter).getyCoor();
        return false;
    }

    public void update(GraphicsContext gc){
        if(this.health<=0) {

        }
        else{
            if (this.isPassed()) {

                this.XDirection = this.checkpointList.get(counter).getxDirection();
                this.YDirection = this.checkpointList.get(counter).getyDirection();
                this.counter++;
            }

            this.setX((this.getX() + this.getSpeed() * this.XDirection));
            this.setY((this.getY() + this.getSpeed() * this.YDirection));
            this.center.setX((long) this.X + 32);
            this.center.setY((long) this.Y + 32);
            this.Draw(gc);
        }
    }

     public long getSize(){
        return this.width;
     }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }
    public void getDamage(int strength){
        this.health-= strength;
    }

    public int getXDirection() {
        return XDirection;
    }

    public void setXDirection(int XDirection) {
        this.XDirection = XDirection;
    }

    public int getYDirection() {
        return YDirection;
    }

    public void setYDirection(int YDirection) {
        this.YDirection = YDirection;
    }


    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public long getReward() {
        return reward;
    }

    public void setReward(long reward) {
        this.reward = reward;
    }

    public long getHealth() {
        return health;
    }

    public void setHealth(long health) {
        this.health = health;
    }

    public boolean isAlive() {
        return Alive;
    }

    public void setAlive(boolean alive) {
        Alive = alive;
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }
}
